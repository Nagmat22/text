from django.apps import AppConfig


class examConfig(AppConfig):
    name = 'exam'
